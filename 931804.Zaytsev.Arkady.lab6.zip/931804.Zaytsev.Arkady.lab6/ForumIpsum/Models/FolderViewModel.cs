﻿using System;

namespace ForumIpsum.Models
{
    public class FolderViewModel
    {
        public string Name { get; set; }
        public Guid? FolderId { get; set; }
    }
}
